// lets create some sample list of data

const list = [
  {
    title: 'Tell me the truth without words',
    url: 'http://kaloraat.com',
    author: 'Ryan',
    num_comments: 100,
    points: 50,
    objectID: 1
  },
  {
    title: 'Oh no! The candle is out',
    url: 'http://kaloraat.com',
    author: 'Zen',
    num_comments: 50,
    points: 20,
    objectID: 2
  },
  {
    title: 'The hard earned black belt',
    url: 'http://kaloraat.com',
    author: 'Ninja',
    num_comments: 10,
    points: 5,
    objectID: 3
  }
]

export default list;